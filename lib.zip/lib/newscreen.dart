import 'package:first_app/widgets/profile_tile.dart';
import 'package:flutter/material.dart';

class Newscreen extends StatelessWidget {
  const Newscreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Flutter Demo App')
          
        ),
        body: const Column(
          children: [
            ProfileTile(),
            ProfileTile(),
          ],
        )
      ),
    );
  }
}