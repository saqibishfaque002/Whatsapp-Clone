import 'package:flutter/material.dart';

class ProfileTile extends StatelessWidget {
  const ProfileTile({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 1),
      child: ListTile(
          tileColor: Colors.green,
          leading: CircleAvatar(backgroundColor: Colors.blue[300]),
          title: const Text("Saqib Ishfaque"),
          subtitle: const Text("Online"),
          trailing: const Text("9:00"),
        
      ),
    );
  }
}